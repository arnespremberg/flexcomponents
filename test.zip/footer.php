<!-- site footer -->
<div class="outer-footer">
	<footer class="site-footer">
		<div class="container">				
		</div>
	</footer>
</div>

 <!-- endbuild -->
<?php wp_footer() ?>


</body>
</html>