<?php

function add_test8_layout($parent) {

    //add your custom fields here
    $fields = array(
        array(
            'key' => 'test8_content',
            'label' => 'test8_content',
            'name' => 'test8_content',
            'type' => 'wysiwyg',
            'parent' => 'flexcomp'
        ),
    );


    //don't edit this code below here unless you know what you're doing
    $layout = array (
        'key' => 'test8',
        'name' => 'test8',
        'label' => 'test8',
        'display' => 'block',
        'sub_fields' => $fields,
        'min' => '',
        'max' => '',
      );
    $parent['layouts'][] = $layout;
    return $parent;
}

add_filter( 'acf/load_field/key=flexcomp_content', 'add_test8_layout' );