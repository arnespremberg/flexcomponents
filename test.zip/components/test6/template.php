<section class="test6">
    <?php the_field('test6_content'); ?>
</section>