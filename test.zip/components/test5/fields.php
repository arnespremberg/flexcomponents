<?php

function add_test5_layout($parent) {

    //add your custom fields here
    $fields = array(
        array(
            'key' => 'test5_content',
            'label' => 'test5_content',
            'name' => 'test5_content',
            'type' => 'wysiwyg',
            'parent' => 'flexcomp'
        ),
    );


    //don't edit this code below here unless you know what you're doing
    $layout = array (
        'key' => 'test5',
        'name' => 'test5',
        'label' => 'test5',
        'display' => 'block',
        'sub_fields' => $fields,
        'min' => '',
        'max' => '',
      );
    $parent['layouts'][] = $layout;
    return $parent;
}

add_filter( 'acf/load_field/key=flexcomp_content', 'add_test5_layout' );