<?php

function add_textblock_layout($parent) {

    //add your custom fields here
    $fields = array(
        array(
            'key' => 'textblock_content',
            'label' => 'textblock_content',
            'name' => 'textblock_content',
            'type' => 'wysiwyg',
            'parent' => 'flexcomp'
        ),
    );


    //don't edit this code below here unless you know what you're doing
    $layout = array (
        'key' => 'textblock',
        'name' => 'textblock',
        'label' => 'textblock',
        'display' => 'block',
        'sub_fields' => $fields,
        'min' => '',
        'max' => '',
      );
    $parent['layouts'][] = $layout;
    return $parent;
}

add_filter( 'acf/load_field/key=flexcomp_content', 'add_textblock_layout' );