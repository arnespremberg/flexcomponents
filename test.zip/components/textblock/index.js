"use strict";

alert("test");