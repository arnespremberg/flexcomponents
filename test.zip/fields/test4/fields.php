<?php

function add_test4_layout($parent) {

    //add your custom fields here
    $fields = array(
        array(
            'key' => 'test4_content',
            'label' => 'test4_content',
            'name' => 'test4_content',
            'type' => 'wysiwyg',
            'parent' => 'flexcomp'
        ),
    );


    //don't edit this code below here unless you know what you're doing
    $layout = array (
        'key' => 'test4',
        'name' => 'test4',
        'label' => 'test4',
        'display' => 'block',
        'sub_fields' => $fields,
        'min' => '',
        'max' => '',
      );
    $parent['layouts'][] = $layout;
    return $parent;
}

add_filter( 'acf/load_field/key=flexcomp_content', 'add_test4_layout' );