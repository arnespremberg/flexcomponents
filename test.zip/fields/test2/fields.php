<?php

function add_test2_layout($parent) {

    //add your custom fields here
    $fields = array(
        array(
            'key' => 'field_1',
            'label' => 'Sub Title',
            'name' => 'sub_title',
            'type' => 'WYSIWYG',
            'parent' => 'flexcomp'
        ),
    );


    //don't edit this code below here unless you know what you're doing
    $layout = array (
        'key' => 'test2',
        'name' => 'test2',
        'label' => 'test2',
        'display' => 'block',
        'sub_fields' => $fields,
        'min' => '',
        'max' => '',
      );
    $parent['layouts'][] = $layout;
    return $parent;
}

add_filter( 'acf/load_field/key=flexcomp_content', 'add_test2_layout' );