<?php

/* if( function_exists('acf_add_local_field') ) {
    acf_add_local_field(array(
        'key' => 'field_1',
        'label' => 'Sub Title',
        'name' => 'sub_title',
        'type' => 'text',
        'parent' => 'flexcomp'
    ));
} */

function add_layout($field) {
    exit("test");
    $layout = array (
        'label' => 'COMPONENT',
        'name' => 'COMPONENT',
        'display' => 'row',
        'sub_fields' => array(
            'key' => 'field_1',
            'label' => 'Sub Title',
            'name' => 'sub_title',
            'type' => 'text',
            'parent' => 'flexcomp'
        ),
    );
    $field['layouts'][] = $layout;
    return $field;
}

add_filter( 'acf/load_field/key=flexcomp_content', 'add_layout' );