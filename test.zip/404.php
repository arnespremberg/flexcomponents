<?php
/**
 * The template for displaying 404 pages (Not Found)
 *
 */

get_header(); ?>

<main>
	<div>
		<p>
			The page you're looking for seems not to be here.
		</p>
	</div>
</main>

<?php get_footer(); ?>
