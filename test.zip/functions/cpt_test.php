<?php

/**
 * Registers the `test` post type.
 */
function test_init() {
	register_post_type( 'test', array(
		'labels'                => array(
			'name'                  => __( 'Tests', 'YOUR-TEXTDOMAIN' ),
			'singular_name'         => __( 'Test', 'YOUR-TEXTDOMAIN' ),
			'all_items'             => __( 'All Tests', 'YOUR-TEXTDOMAIN' ),
			'archives'              => __( 'Test Archives', 'YOUR-TEXTDOMAIN' ),
			'attributes'            => __( 'Test Attributes', 'YOUR-TEXTDOMAIN' ),
			'insert_into_item'      => __( 'Insert into test', 'YOUR-TEXTDOMAIN' ),
			'uploaded_to_this_item' => __( 'Uploaded to this test', 'YOUR-TEXTDOMAIN' ),
			'featured_image'        => _x( 'Featured Image', 'test', 'YOUR-TEXTDOMAIN' ),
			'set_featured_image'    => _x( 'Set featured image', 'test', 'YOUR-TEXTDOMAIN' ),
			'remove_featured_image' => _x( 'Remove featured image', 'test', 'YOUR-TEXTDOMAIN' ),
			'use_featured_image'    => _x( 'Use as featured image', 'test', 'YOUR-TEXTDOMAIN' ),
			'filter_items_list'     => __( 'Filter tests list', 'YOUR-TEXTDOMAIN' ),
			'items_list_navigation' => __( 'Tests list navigation', 'YOUR-TEXTDOMAIN' ),
			'items_list'            => __( 'Tests list', 'YOUR-TEXTDOMAIN' ),
			'new_item'              => __( 'New Test', 'YOUR-TEXTDOMAIN' ),
			'add_new'               => __( 'Add New', 'YOUR-TEXTDOMAIN' ),
			'add_new_item'          => __( 'Add New Test', 'YOUR-TEXTDOMAIN' ),
			'edit_item'             => __( 'Edit Test', 'YOUR-TEXTDOMAIN' ),
			'view_item'             => __( 'View Test', 'YOUR-TEXTDOMAIN' ),
			'view_items'            => __( 'View Tests', 'YOUR-TEXTDOMAIN' ),
			'search_items'          => __( 'Search tests', 'YOUR-TEXTDOMAIN' ),
			'not_found'             => __( 'No tests found', 'YOUR-TEXTDOMAIN' ),
			'not_found_in_trash'    => __( 'No tests found in trash', 'YOUR-TEXTDOMAIN' ),
			'parent_item_colon'     => __( 'Parent Test:', 'YOUR-TEXTDOMAIN' ),
			'menu_name'             => __( 'Tests', 'YOUR-TEXTDOMAIN' ),
		),
		'public'                => true,
		'hierarchical'          => false,
		'show_ui'               => true,
		'show_in_nav_menus'     => true,
		'supports'              => array( 'title', 'editor' ),
		'has_archive'           => true,
		'rewrite'               => true,
		'query_var'             => true,
		'menu_position'         => null,
		'menu_icon'             => 'dashicons-admin-post',
		'show_in_rest'          => true,
		'rest_base'             => 'test',
		'rest_controller_class' => 'WP_REST_Posts_Controller',
	) );

}
add_action( 'init', 'test_init' );

/**
 * Sets the post updated messages for the `test` post type.
 *
 * @param  array $messages Post updated messages.
 * @return array Messages for the `test` post type.
 */
function test_updated_messages( $messages ) {
	global $post;

	$permalink = get_permalink( $post );

	$messages['test'] = array(
		0  => '', // Unused. Messages start at index 1.
		/* translators: %s: post permalink */
		1  => sprintf( __( 'Test updated. <a target="_blank" href="%s">View test</a>', 'YOUR-TEXTDOMAIN' ), esc_url( $permalink ) ),
		2  => __( 'Custom field updated.', 'YOUR-TEXTDOMAIN' ),
		3  => __( 'Custom field deleted.', 'YOUR-TEXTDOMAIN' ),
		4  => __( 'Test updated.', 'YOUR-TEXTDOMAIN' ),
		/* translators: %s: date and time of the revision */
		5  => isset( $_GET['revision'] ) ? sprintf( __( 'Test restored to revision from %s', 'YOUR-TEXTDOMAIN' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		/* translators: %s: post permalink */
		6  => sprintf( __( 'Test published. <a href="%s">View test</a>', 'YOUR-TEXTDOMAIN' ), esc_url( $permalink ) ),
		7  => __( 'Test saved.', 'YOUR-TEXTDOMAIN' ),
		/* translators: %s: post permalink */
		8  => sprintf( __( 'Test submitted. <a target="_blank" href="%s">Preview test</a>', 'YOUR-TEXTDOMAIN' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
		/* translators: 1: Publish box date format, see https://secure.php.net/date 2: Post permalink */
		9  => sprintf( __( 'Test scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview test</a>', 'YOUR-TEXTDOMAIN' ),
		date_i18n( __( 'M j, Y @ G:i', 'YOUR-TEXTDOMAIN' ), strtotime( $post->post_date ) ), esc_url( $permalink ) ),
		/* translators: %s: post permalink */
		10 => sprintf( __( 'Test draft updated. <a target="_blank" href="%s">Preview test</a>', 'YOUR-TEXTDOMAIN' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
	);

	return $messages;
}
add_filter( 'post_updated_messages', 'test_updated_messages' );
